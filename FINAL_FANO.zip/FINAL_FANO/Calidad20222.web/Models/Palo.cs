namespace Calidad20222.web.Models;

public class Palo
{
    public const String CORAZON = "CORAZON";
    public const String TREBOL = "TREBOL";
    public const String ESPADA = "ESPADA";
    public const String COCO = "COCO";
}